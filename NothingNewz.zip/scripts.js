let page = 1;
let isLoading = false;

function debounce(func, delay) {
  let timeout;
  return () => {
    clearTimeout(timeout);
    timeout = setTimeout(func, delay);
  };
}

async function fetchNews(reset = false) {
  if (isLoading) return;
  isLoading = true;
  loading.style.display = 'block';

  const { mode, value } = getSearchParams();
  let url = '';

  if (mode === 'search') {
    url = `https://newsapi.org/v2/everything?q=${encodeURIComponent(value)}&pageSize=10&page=${page}&apiKey=${API_KEY}`;
  } else {
    url = `https://newsapi.org/v2/top-headlines?country=us&category=${value}&pageSize=10&page=${page}&apiKey=${API_KEY}`;
  }

  try {
    const res = await fetch(url);
    const data = await res.json();

    if (reset) {
      newsContainer.innerHTML = '';
      page = 1;
    }

    if (data.articles?.length > 0) {
      data.articles.forEach(article => {
        const card = document.createElement('div');
        card.className = 'card';
        card.innerHTML = `
          <img src="${article.urlToImage || 'https://via.placeholder.com/400x200'}" alt="">
          <h2>${article.title}</h2>
          <p>${article.description || 'No description available.'}</p>
          <a href="${article.url}" target="_blank">Read More →</a>
        `;
        newsContainer.appendChild(card);
      });
      page++;
    } else if (reset) {
      newsContainer.innerHTML = `<p>No news found for <b>${value}</b>.</p>`;
    }
  } catch (err) {
    console.error('Error:', err);
    if (reset) newsContainer.innerHTML = `<p>Error: ${err.message}</p>`;
  } finally {
    isLoading = false;
    loading.style.display = 'none';
  }
}

// Infinite scroll trigger
window.addEventListener(
  'scroll',
  debounce(() => {
    if (window.innerHeight + window.scrollY >= document.body.offsetHeight - 300) {
      fetchNews();
    }
  }, 200)
);